<script setup lang="ts"></script>

<template>
  <div>test组件11</div>
</template>

<style scoped></style>
