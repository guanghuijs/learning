export { default as Test } from './src/index.vue';
