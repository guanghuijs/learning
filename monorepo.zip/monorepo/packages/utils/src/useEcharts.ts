export function useEcharts() {
  console.log('useEcharts');
}
