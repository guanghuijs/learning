<script setup lang="ts">
import { Test } from '@ghui/components'
</script>

<template>
  <Test></Test>
</template>

<style scoped></style>
